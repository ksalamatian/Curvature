//
// Created by Kave Salamatian on 20/04/2021.
//

#include <stdio.h>
#include <iostream>
#include <utility>
#include <string>
#include <boost/graph/adjacency_list.hpp>
#include <boost/graph/graph_utility.hpp>
#include <boost/graph/graphml.hpp>
#include <boost/property_map/dynamic_property_map.hpp>
#include <boost/property_map/property_map.hpp>
#include <boost/graph/graph_traits.hpp>
#include <boost/graph/dijkstra_shortest_paths.hpp>
#include <boost/graph/copy.hpp>
#include <boost/multi_index_container.hpp>
#include <boost/multi_index/ordered_index.hpp>
#include <boost/multi_index/member.hpp>
#include <boost/multi_index/composite_key.hpp>
#include <fstream>
#include <boost/iostreams/filtering_stream.hpp>
#include <boost/iostreams/filter/gzip.hpp>
#include "emd.h"
#include <vector>
#include <set>
#include <tbb/parallel_for.h>
#include<chrono>
#include <queue>
#include "LruCache.h"




using namespace boost;
using namespace std;
using namespace tbb;
using std::chrono::high_resolution_clock;
using std::chrono::duration_cast;
using std::chrono::duration;
using std::chrono::milliseconds;

struct Vertex_info;
struct Edge_info;
typedef boost::adjacency_list <boost::vecS, boost::vecS, boost::undirectedS, Vertex_info, Edge_info > Graph_t;
typedef boost::graph_traits < Graph_t >::vertex_iterator VertexIterator;
typedef boost::graph_traits < Graph_t >::edge_iterator EdgeIterator;
typedef boost::graph_traits < Graph_t >::adjacency_iterator AdjacencyIterator;
typedef boost::graph_traits < Graph_t >::vertex_descriptor Vertex;
typedef boost::graph_traits < Graph_t >::edge_descriptor Edge;
typedef boost::property_map < Graph_t, boost::vertex_index_t >::type IndexMap;

struct Vertex_info {
    std::string country;
    std::string name;
    int prefixnum;
    int prefixall;
    int astime;
    int addall;
    int addnum;
    std::string asnumber;
    int pathnum;
    map<Vertex, double> distances;
    double potential;
};

struct Edge_info {
    int weight= 1;
    long pathcount;
    int edgetime;
    //int ctime;
    int prefcount;
    double distance=1.0;
    double curvature=0.0;
    bool visited=false;
};

map<long, mutex> graphMutexes;


/*
 * Read a graphml
 */
void readGraphMLFile ( Graph_t& designG, std::string fileName ) {
    boost::dynamic_properties dp;
    dp.property("asNumber", get(&Vertex_info::asnumber, designG));
    //dp.property("pathnum", get(&Vertex_info::pathnum, designG));
    dp.property("Country", get(&Vertex_info::country, designG));
    dp.property("Name", get(&Vertex_info::name, designG));
    dp.property("asTime", get(&Vertex_info::astime, designG));
    dp.property("prefixNum", get(&Vertex_info::prefixnum, designG));
    dp.property("prefixAll", get(&Vertex_info::prefixall, designG));
    // dp.property("addAll", get(&Vertex_info::addall, designG));
    // dp.property("addNum", get(&Vertex_info::addnum, designG));
    dp.property("count", get(&Edge_info::pathcount, designG));
    dp.property("edgeTime", get(&Edge_info::edgetime, designG));
    dp.property("weight", get(&Edge_info::weight, designG));
    dp.property("distance", get(&Edge_info::distance, designG));

    ifstream inFile;
    inFile.open(fileName, ifstream::in);
    try {
        boost::read_graphml(inFile, designG, dp);
    }
    catch (const std::exception &exc) {
        cerr << exc.what();
        cout << "Type: " << typeid(exc).name() << "\n";
    }
    cout << "Num Vertices: " << num_vertices(designG) << endl;
    cout << "Num Edges: " << num_edges(designG) << endl;
    inFile.close();
}

void multiSourceCone(Vertex v, Graph_t& g, set<Vertex> &sources, set<Vertex> &dests){
    pair<AdjacencyIterator, AdjacencyIterator> nA = adjacent_vertices(v, g);
    int sA = out_degree(v, g);
    mutex m;
    for (; nA.first != nA.second;nA.first++ ){
        Vertex w=*(nA.first);
        sources.insert(w);
        auto e = edge(v, w, g);
        long key=w<<32+v;
        bool visited=false;
        if (graphMutexes.count(key)==0){
            key=v<<32+w;
        }
        if (graphMutexes[key].try_lock()) {
            g[e.first].visited=true;
            graphMutexes[key].unlock();
        } else {
            visited=true;
        }
        if (!visited){
            pair<AdjacencyIterator, AdjacencyIterator> nB = adjacent_vertices(*(nA.first), g);
            for (; nB.first != nB.second; dests.insert(*(nB.first++)));
        }
    }
}

/*
 * To limite the visited edge in the dijkstra algorithm
 */
class My_visitor : boost::default_bfs_visitor{
protected:
    set<Vertex> dests;
public:
    My_visitor( const set<Vertex> destset)
            : dests(destset) {};
    void initialize_vertex(const Vertex &s, const Graph_t &g) const {}
    void discover_vertex(const Vertex &s, const Graph_t &g) const {}
    void examine_vertex(const Vertex &s, const Graph_t &g) const {}
    void examine_edge(const Edge &e, const Graph_t &g) const {}
    void edge_relaxed(const Edge &e, const Graph_t &g) const {}
    void edge_not_relaxed(const Edge &e, const Graph_t &g) const {}
    void finish_vertex(const Vertex &s, const Graph_t &g) {
        dests.erase(s);
        if (dests.empty())
            throw(2);
    }
};

void k_core(Graph_t &gin, Graph_t &gout, int k){

    Graph_t *before, *after, empty;
    before= &gin;
    Graph_t::vertex_descriptor vsource, vsource1,vdest, vdest1;
    std::pair<Graph_t::edge_descriptor, bool> e;
    cout<<"k-core 0 size is:"<<num_vertices(gin)<<","<<num_edges(gin)<<endl;
    for(int i=0;i<k;i++) {
        Graph_t *after, empty;
        after=&empty;
        vector<int> color(num_vertices(*before), 0);
        IndexMap index = get(vertex_index, *before);
        bool addEdge, sourceOK, destOK;
        vector<Vertex> indices(num_vertices(*before),1000000);
        auto es = edges(*before);
        for (auto eit = es.first; eit != es.second; ++eit) {
            sourceOK=false;
            destOK=false;
            vsource1 = source(*eit, *before);
            if (color[vsource1] == 0) {
                if (degree(vsource1, *before) > 1) {
                    vsource = add_vertex(*after);
                    indices[vsource1]=vsource;
                    (*after)[vsource].name = (*before)[vsource1].name;
                    (*after)[vsource].country = (*before)[vsource1].country;
                    (*after)[vsource].astime = (*before)[vsource1].astime;
                    (*after)[vsource].pathnum = (*before)[vsource1].pathnum;
                    (*after)[vsource].prefixnum = (*before)[vsource1].prefixnum;
                    (*after)[vsource].prefixall = (*before)[vsource1].prefixall;
                    (*after)[vsource].asnumber = (*before)[vsource1].asnumber;
                    sourceOK=true;
                    color[vsource1]= 1;
                }
            } else {
                vsource= indices[vsource1];
                sourceOK=true;
            }
            vdest1 = target(*eit, *before);
            if (vdest1 != vsource1) {
                if (color[vdest1] == 0) {
                    if (degree(vdest1, *before) > 1) {
                        vdest = add_vertex(*after);
                        indices[vdest1]=vdest;
                        (*after)[vdest].name = (*before)[vdest1].name;
                        (*after)[vdest].country = (*before)[vdest1].country;
                        (*after)[vdest].astime = (*before)[vdest1].astime;
                        (*after)[vdest].pathnum = (*before)[vdest1].pathnum;
                        (*after)[vdest].prefixnum = (*before)[vdest1].prefixnum;
                        (*after)[vdest].prefixall = (*before)[vdest1].prefixall;
                        (*after)[vdest].asnumber = (*before)[vdest1].asnumber;
                        destOK = true;
                        color[vdest1] = 1;
                    }
                } else {
                    vdest=indices[vdest1];
                    destOK = true;
                }
            }
            if (sourceOK && destOK){
                e = add_edge(vsource, vdest, *after);
                (*after)[e.first].weight = (*before)[*eit].weight;
                (*after)[e.first].pathcount = (*before)[*eit].pathcount;
                (*after)[e.first].edgetime = (*before)[*eit].edgetime;
                (*after)[e.first].prefcount = (*before)[*eit].prefcount;
                (*after)[e.first].distance = (*before)[*eit].distance;
            }
        }
        cout<<"k-core "<<i+1<<" size is:"<<num_vertices(*after)<<","<<num_edges(*after)<<endl;
        before->clear();
        copy_graph(*after,*before);
        indices.clear();
    }

    copy_graph(*before,gout);
}




class IntNode {
public:
    Vertex v;
    double distance=std::numeric_limits<double>::infinity(); //distance from source v
    bool visited=false; //this node has been visited by source v
    IntNode(){};
    IntNode(Vertex v,double dist): v(v),distance(dist){};
    IntNode(const IntNode &node): v(node.v), distance(node.distance){}
    struct distChange : public std::unary_function<IntNode,void> {
        double d; distChange(const double &_d) : d(_d) {}
        void operator()(IntNode *node) { node->distance = d;}
    };
};

struct IntNodeByV {};
struct IntNodeByD {};
using InternalHeap=  boost::multi_index_container< IntNode*, // the data type stored
        boost::multi_index::indexed_by< // list of indexes
                boost::multi_index::ordered_unique<  //hashed index over Vertex
                        boost::multi_index::tag<IntNodeByV>, // give that index a name
                        boost::multi_index::member<IntNode, Vertex, &IntNode::v> // what will be the index's key
                >,
                boost::multi_index::ordered_non_unique<  //hashed non-unique index over distance vector
                        boost::multi_index::tag<IntNodeByD>, // give that index a name
                        boost::multi_index::member<IntNode, double, &IntNode::distance > // what will be the index's key
                >
        >
>;



class DistanceCache{
private:
    ThreadSafeScalableCache<long, double> distanceCache;
public:
    int cacheSize;
    int hit=0;
    int miss=0;
    DistanceCache(size_t maxSize, size_t numShards):distanceCache(maxSize, numShards){}
    ~DistanceCache(){
        distanceCache.clear();
        delete &distanceCache;
    }
    pair<bool, short int> insert(const Vertex src, const Vertex dst, double value){
        long key= src;
        key=(key<<32)+dst;
        return distanceCache.insert(key,value);
    }

    double find(const Vertex src, const Vertex dst) {
        // return the distance if he finds it and -1 if not
        ThreadSafeScalableCache<long, double>::ConstAccessor ac;
        long key= src;
        key=(key<<32)+dst;
        if (distanceCache.find(ac,key)){
            hit++;
            return *ac;
        }
        key=dst;
        key=(key<<32)+src;
        if (distanceCache.find(ac,key)){
            hit++;
            return *ac;
        }
        miss++;
        return -1;
    }
};

struct VisNodeByV {};
struct VisNodeByD {};
class VisNode {
private:
    double potential;
    InternalHeap sortedDistances;
public:
    double minDist;
    map<Vertex, IntNode> settled;
    set<Vertex> unprocessed;
    typename boost::multi_index::index<InternalHeap,IntNodeByV>::type& indexNodeByV = sortedDistances.get<IntNodeByV>(); // here's where index tags (=names) come in handy
    typename boost::multi_index::index<InternalHeap,IntNodeByD>::type& indexNodeByD = sortedDistances.get<IntNodeByD>();
    Vertex v;

    VisNode(Vertex v, set<Vertex> &sources, DistanceCache &distanceCache ): v(v){
        double dist;
        for(Vertex w:sources){
            dist=distanceCache.find(v,w);
            if  (dist>-1){
                settled[w].distance=dist;
                settled[w].v=w;
                settled[w].visited=false;
                unprocessed.insert(w);
            } else {
                indexNodeByD.insert(new IntNode(w,std::numeric_limits<double>::infinity()));
            }
        }
        potential=0.0;
        minDist=std::numeric_limits<double>::infinity();
    }

    ~VisNode(){
        for (auto p:indexNodeByV){
            delete p;
        }
        sortedDistances.clear();
        settled.clear();
    }

    double get_potential(Vertex node,Graph_t &g, set<Vertex> &landMarks, Vertex target, DistanceCache &distanceCache){
        double maxPotential=0.0;
        for(Vertex v:landMarks) {
            double dnode=distanceCache.find(v,node);
            double dtarget=distanceCache.find(v,target);
            if ((dnode>-1) && (dtarget>-1))
                maxPotential=max(maxPotential,abs(dnode-dtarget));
        }
        return maxPotential;
    }


    IntNode get_settledIntNode(Vertex w){
        return settled[w];
    }

    bool update_distance(Vertex w, double d){
        if (settled.count(w)==0){
            auto it=indexNodeByV.find(w);
            if ((*it)->distance>d){
                indexNodeByV.modify(it,IntNode::distChange(d));
                double minDistC=minDist;
                minDist=(*indexNodeByD.begin())->distance+potential;
                if (minDist<minDistC)
                    return true;
            }
        }
        return false;
    }

    void update_potential(Vertex target, Graph_t &g, set<Vertex> landMarks, DistanceCache &distanceCache){
        potential= get_potential(v,g, landMarks, target, distanceCache);
        if (indexNodeByV.size()>0)
            minDist=(*indexNodeByD.begin())->distance+potential;
        else
            minDist=potential;
    }

    double get_minDistance(){
        if (indexNodeByV.size()>0)
            return (*(indexNodeByD.begin()))->distance;
        else
            return std::numeric_limits<double>::infinity();
    }

    double get_minPotentialDistance(){
        return minDist;
    }

    IntNode get_headSource(){
        return **(indexNodeByD.begin());
    }


    struct update_minDist : public std::unary_function<VisNode,void> {
        double d; update_minDist(const double &_d) : d(_d) {}
        void operator()(VisNode *node) { node->minDist = d+node->potential;}
    };

    set<Vertex> settle_distances(double nextDist, DistanceCache &distanceCache) {
        //check if any distance can be settled
        set<Vertex> newSettled;
        //
        // Created by Kave Salamatian on 20/04/2021.
        //

#include <stdio.h>
#include <iostream>
#include <utility>
#include <string>
#include <boost/graph/adjacency_list.hpp>
#include <boost/graph/graph_utility.hpp>
#include <boost/graph/graphml.hpp>
#include <boost/property_map/dynamic_property_map.hpp>
#include <boost/property_map/property_map.hpp>
#include <boost/graph/graph_traits.hpp>
#include <boost/graph/dijkstra_shortest_paths.hpp>
#include <boost/graph/copy.hpp>
#include <boost/multi_index_container.hpp>
#include <boost/multi_index/ordered_index.hpp>
#include <boost/multi_index/member.hpp>
#include <boost/multi_index/composite_key.hpp>
#include <fstream>
#include <boost/iostreams/filtering_stream.hpp>
#include <boost/iostreams/filter/gzip.hpp>
#include "emd.h"
#include <vector>
#include <set>
#include <tbb/parallel_for.h>
#include<chrono>
#include <queue>
#include "LruCache.h"




using namespace boost;
using namespace std;
using namespace tbb;
using std::chrono::high_resolution_clock;
using std::chrono::duration_cast;
using std::chrono::duration;
using std::chrono::milliseconds;

struct Vertex_info;
struct Edge_info;
typedef boost::adjacency_list <boost::vecS, boost::vecS, boost::undirectedS, Vertex_info, Edge_info > Graph_t;
typedef boost::graph_traits < Graph_t >::vertex_iterator VertexIterator;
typedef boost::graph_traits < Graph_t >::edge_iterator EdgeIterator;
typedef boost::graph_traits < Graph_t >::adjacency_iterator AdjacencyIterator;
typedef boost::graph_traits < Graph_t >::vertex_descriptor Vertex;
typedef boost::graph_traits < Graph_t >::edge_descriptor Edge;
typedef boost::property_map < Graph_t, boost::vertex_index_t >::type IndexMap;

struct Vertex_info {
    std::string country;
    std::string name;
    int prefixnum;
    int prefixall;
    int astime;
    int addall;
    int addnum;
    std::string asnumber;
    int pathnum;
    double potential;
};

struct Edge_info {
    int weight= 1;
    long pathcount;
    int edgetime;
    //int ctime;
    int prefcount;
    double distance=1.0;
    double curvature=0.0;
    bool visited=false;
};

map<long, mutex> graphMutexes;
std::atomic<int> matchedVertices(0), checkedVertices(0);


/*
 * Read a graphml
 */
void readGraphMLFile ( Graph_t& designG, std::string fileName ) {
    boost::dynamic_properties dp;
    dp.property("asNumber", get(&Vertex_info::asnumber, designG));
    //dp.property("pathnum", get(&Vertex_info::pathnum, designG));
    dp.property("Country", get(&Vertex_info::country, designG));
    dp.property("Name", get(&Vertex_info::name, designG));
    dp.property("asTime", get(&Vertex_info::astime, designG));
    dp.property("prefixNum", get(&Vertex_info::prefixnum, designG));
    dp.property("prefixAll", get(&Vertex_info::prefixall, designG));
    // dp.property("addAll", get(&Vertex_info::addall, designG));
    // dp.property("addNum", get(&Vertex_info::addnum, designG));
    dp.property("count", get(&Edge_info::pathcount, designG));
    dp.property("edgeTime", get(&Edge_info::edgetime, designG));
    dp.property("weight", get(&Edge_info::weight, designG));
    dp.property("distance", get(&Edge_info::distance, designG));

    ifstream inFile;
    inFile.open(fileName, ifstream::in);
    try {
        boost::read_graphml(inFile, designG, dp);
    }
    catch (const std::exception &exc) {
        cerr << exc.what();
        cout << "Type: " << typeid(exc).name() << "\n";
    }
    cout << "Num Vertices: " << num_vertices(designG) << endl;
    cout << "Num Edges: " << num_edges(designG) << endl;
    inFile.close();
}

void multiSourceCone(Vertex v, Graph_t& g, set<Vertex> &sources, set<Vertex> &dests){
    pair<AdjacencyIterator, AdjacencyIterator> nA = adjacent_vertices(v, g);
    for (; nA.first != nA.second;nA.first++ ){
        checkedVertices++;
        Vertex w=*(nA.first);
        sources.insert(w);
        pair<Edge,bool> e;
        long key=(w<<32)+v;
        bool visited=false;
        e= edge(v, w, g);
        if (graphMutexes.count(key)==0){
            key=(v<<32)+w;
            e= edge(w,v,g);
        }
        if (graphMutexes[key].try_lock()) {
            if (!g[e.first].visited){
                g[e.first].visited=true;
            } else {
                matchedVertices++;
                visited=true;
            }
            graphMutexes[key].unlock();
        } else {
            visited=true;
            matchedVertices++;
        }
        if (!visited){
            pair<AdjacencyIterator, AdjacencyIterator> nB = adjacent_vertices(*(nA.first), g);
            for (; nB.first != nB.second; dests.insert(*(nB.first++)));
        }
    }
}

/*
 * To limite the visited edge in the dijkstra algorithm
 */
class My_visitor : boost::default_bfs_visitor{
protected:
    set<Vertex> dests;
public:
    My_visitor( const set<Vertex> destset)
    : dests(destset) {};
    void initialize_vertex(const Vertex &s, const Graph_t &g) const {}
    void discover_vertex(const Vertex &s, const Graph_t &g) const {}
    void examine_vertex(const Vertex &s, const Graph_t &g) const {}
    void examine_edge(const Edge &e, const Graph_t &g) const {}
    void edge_relaxed(const Edge &e, const Graph_t &g) const {}
    void edge_not_relaxed(const Edge &e, const Graph_t &g) const {}
    void finish_vertex(const Vertex &s, const Graph_t &g) {
        dests.erase(s);
        if (dests.empty())
            throw(2);
    }
};

void k_core(Graph_t &gin, Graph_t &gout, int k){

    Graph_t *before, empty;
    before= &gin;
    Graph_t::vertex_descriptor vsource, vsource1,vdest, vdest1;
    std::pair<Graph_t::edge_descriptor, bool> e;
    cout<<"k-core 0 size is:"<<num_vertices(gin)<<","<<num_edges(gin)<<endl;
    for(int i=0;i<k;i++) {
        Graph_t *after, empty;
        after=&empty;
        vector<int> color(num_vertices(*before), 0);
        bool sourceOK, destOK;
        vector<Vertex> indices(num_vertices(*before),1000000);
        auto es = edges(*before);
        for (auto eit = es.first; eit != es.second; ++eit) {
            sourceOK=false;
            destOK=false;
            vsource1 = source(*eit, *before);
            if (color[vsource1] == 0) {
                if (degree(vsource1, *before) > 1) {
                    vsource = add_vertex(*after);
                    indices[vsource1]=vsource;
                    (*after)[vsource].name = (*before)[vsource1].name;
                    (*after)[vsource].country = (*before)[vsource1].country;
                    (*after)[vsource].astime = (*before)[vsource1].astime;
                    (*after)[vsource].pathnum = (*before)[vsource1].pathnum;
                    (*after)[vsource].prefixnum = (*before)[vsource1].prefixnum;
                    (*after)[vsource].prefixall = (*before)[vsource1].prefixall;
                    (*after)[vsource].asnumber = (*before)[vsource1].asnumber;
                    sourceOK=true;
                    color[vsource1]= 1;
                }
            } else {
                vsource= indices[vsource1];
                sourceOK=true;
            }
            vdest1 = target(*eit, *before);
            if (vdest1 != vsource1) {
                if (color[vdest1] == 0) {
                    if (degree(vdest1, *before) > 1) {
                        vdest = add_vertex(*after);
                        indices[vdest1]=vdest;
                        (*after)[vdest].name = (*before)[vdest1].name;
                        (*after)[vdest].country = (*before)[vdest1].country;
                        (*after)[vdest].astime = (*before)[vdest1].astime;
                        (*after)[vdest].pathnum = (*before)[vdest1].pathnum;
                        (*after)[vdest].prefixnum = (*before)[vdest1].prefixnum;
                        (*after)[vdest].prefixall = (*before)[vdest1].prefixall;
                        (*after)[vdest].asnumber = (*before)[vdest1].asnumber;
                        destOK = true;
                        color[vdest1] = 1;
                    }
                } else {
                    vdest=indices[vdest1];
                    destOK = true;
                }
            }
            if (sourceOK && destOK){
                e = add_edge(vsource, vdest, *after);
                (*after)[e.first].weight = (*before)[*eit].weight;
                (*after)[e.first].pathcount = (*before)[*eit].pathcount;
                (*after)[e.first].edgetime = (*before)[*eit].edgetime;
                (*after)[e.first].prefcount = (*before)[*eit].prefcount;
                (*after)[e.first].distance = (*before)[*eit].distance;
            }
        }
        cout<<"k-core "<<i+1<<" size is:"<<num_vertices(*after)<<","<<num_edges(*after)<<endl;
        before->clear();
        copy_graph(*after,*before);
        indices.clear();
    }

    copy_graph(*before,gout);
}




class IntNode {
public:
    Vertex v;
    double distance=std::numeric_limits<double>::infinity(); //distance from source v
    bool visited=false; //this node has been visited by source v
    IntNode(){};
    IntNode(Vertex v,double dist): v(v),distance(dist){};
    IntNode(const IntNode &node): v(node.v), distance(node.distance){}
    struct distChange : public std::unary_function<IntNode,void> {
        double d; distChange(const double &_d) : d(_d) {}
        void operator()(IntNode *node) { node->distance = d;}
    };
};

struct IntNodeByV {};
struct IntNodeByD {};
using InternalHeap=  boost::multi_index_container< IntNode*, // the data type stored
boost::multi_index::indexed_by< // list of indexes
boost::multi_index::ordered_unique<  //hashed index over Vertex
boost::multi_index::tag<IntNodeByV>, // give that index a name
boost::multi_index::member<IntNode, Vertex, &IntNode::v> // what will be the index's key
>,
boost::multi_index::ordered_non_unique<  //hashed non-unique index over distance vector
boost::multi_index::tag<IntNodeByD>, // give that index a name
boost::multi_index::member<IntNode, double, &IntNode::distance > // what will be the index's key
>
>
>;


class DistanceCache{
private:
    ThreadSafeScalableCache<long, double> distanceCache;
public:
    int cacheSize;
    int hit=0;
    int miss=0;
    DistanceCache(size_t maxSize, size_t numShards):distanceCache(maxSize, numShards){}
    ~DistanceCache(){
        distanceCache.clear();
        delete &distanceCache;
    }
    pair<bool, short int> insert(const Vertex src, const Vertex dst, double value){
        long key= src;
        key=(key<<32)+dst;
        return distanceCache.insert(key,value);
    }

    double find(const Vertex src, const Vertex dst) {
        // return the distance if he finds it and -1 if not
        ThreadSafeScalableCache<long, double>::ConstAccessor ac;
        long key= src;
        key=(key<<32)+dst;
        if (distanceCache.find(ac,key)){
            hit++;
            return *ac;
        }
        key=dst;
        key=(key<<32)+src;
        if (distanceCache.find(ac,key)){
            hit++;
            return *ac;
        }
        miss++;
        return -1;
    }

    int size(){
        return distanceCache.size();
    }
};

struct VisNodeByV {};
struct VisNodeByD {};
class VisNode {
private:
    double potential;
    InternalHeap sortedDistances;
public:
    double minDist;
    map<Vertex, IntNode> settled;
    set<Vertex> unprocessed;
    typename boost::multi_index::index<InternalHeap,IntNodeByV>::type& indexNodeByV = sortedDistances.get<IntNodeByV>(); // here's where index tags (=names) come in handy
    typename boost::multi_index::index<InternalHeap,IntNodeByD>::type& indexNodeByD = sortedDistances.get<IntNodeByD>();
    Vertex v;

    VisNode(Vertex v, set<Vertex> &sources, DistanceCache &distanceCache ): v(v){
        double dist;
        for(Vertex w:sources){
            dist=distanceCache.find(v,w);
            if  (dist>-1){
                settled[w].distance=dist;
                settled[w].v=w;
                settled[w].visited=false;
                unprocessed.insert(w);
            } else {
                indexNodeByD.insert(new IntNode(w,std::numeric_limits<double>::infinity()));
            }
        }
        potential=0.0;
        minDist=std::numeric_limits<double>::infinity();
    }

    ~VisNode(){
        for (auto p:indexNodeByV){
            delete p;
        }
        sortedDistances.clear();
        settled.clear();
    }

    double get_potential(Vertex node,Graph_t &g, set<Vertex> &landMarks, Vertex target, DistanceCache &distanceCache){
        double maxPotential=0.0;
        for(Vertex v:landMarks) {
            double dnode=distanceCache.find(v,node);
            double dtarget=distanceCache.find(v,target);
            if ((dnode>-1) && (dtarget>-1))
                maxPotential=max(maxPotential,abs(dnode-dtarget));
        }
        return maxPotential;
    }


    IntNode get_settledIntNode(Vertex w){
        return settled[w];
    }

    bool update_distance(Vertex w, double d){
        if (settled.count(w)==0){
            auto it=indexNodeByV.find(w);
            if ((*it)->distance>d){
                indexNodeByV.modify(it,IntNode::distChange(d));
                double minDistC=minDist;
                minDist=(*indexNodeByD.begin())->distance+potential;
                if (minDist<minDistC)
                    return true;
            }
        }
        return false;
    }

    void update_potential(Vertex target, Graph_t &g, set<Vertex> landMarks, DistanceCache &distanceCache){
        potential= get_potential(v,g, landMarks, target, distanceCache);
        if (indexNodeByV.size()>0)
            minDist=(*indexNodeByD.begin())->distance+potential;
        else
            minDist=potential;
    }

    double get_minDistance(){
        if (indexNodeByV.size()>0)
            return (*(indexNodeByD.begin()))->distance;
        else
            return std::numeric_limits<double>::infinity();
    }

    double get_minPotentialDistance(){
        return minDist;
    }

    IntNode get_headSource(){
        return **(indexNodeByD.begin());
    }


    struct update_minDist : public std::unary_function<VisNode,void> {
        double d; update_minDist(const double &_d) : d(_d) {}
        void operator()(VisNode *node) { node->minDist = d+node->potential;}
    };

    set<Vertex> settle_distances(double nextDist, DistanceCache &distanceCache) {
        //check if any distance can be settled
        set<Vertex> newSettled;
        auto it =indexNodeByD.begin();
        for(Vertex u:unprocessed){
            newSettled.insert(u);
        }
        unprocessed.clear();
        while (it != indexNodeByD.end()) {
            Vertex currentSource = (*it)->v;
            double currentDistance = (*it)->distance;
            if (currentDistance !=
            std::numeric_limits<double>::infinity()) {// node v has never been reached from currentSource
                if (currentDistance <= nextDist) {
                    newSettled.insert(currentSource);
                    settled[currentSource].distance=(*it)->distance;
                    settled[currentSource].v=(*it)->v;
                    settled[currentSource].visited=(*it)->visited;
                    distanceCache.insert(currentSource, v,currentDistance);
                    delete *it;
                    it = indexNodeByD.erase(it);
                } else {
                    it++;
                }
            } else{
                break;
            }
        }
        if (!is_fullySettled()) {
            minDist=(*indexNodeByD.begin())->distance+potential;
        } else {
            minDist=std::numeric_limits<double>::infinity();
        }
        return newSettled;
    }

    bool is_fullySettled(){
        return (indexNodeByV.size()==0);
    }
};

struct Comp {
    bool operator()(const map<Vertex, IntNode> &a, const map<Vertex, IntNode> &b) const {
        return a.size() < b.size();
    }
};

using Heap = boost::multi_index_container< VisNode*, // the data type stored
boost::multi_index::indexed_by< // list of indexes
boost::multi_index::hashed_unique<  //hashed index over Vertex
boost::multi_index::tag<VisNodeByV>, // give that index a name
boost::multi_index::member<VisNode, Vertex, &VisNode::v> // what will be the index's key
>,
boost::multi_index::ordered_non_unique<  //hashed non-unique index over distance vector
boost::multi_index::tag<VisNodeByD>, // give that index a name
//boost::multi_index::member<VisNode, double, &VisNode::minDist > // what will be the index's key
boost::multi_index::composite_key<VisNode,
boost::multi_index::member<VisNode, double, &VisNode::minDist>,
boost::multi_index::member<VisNode, map<Vertex, IntNode>, &VisNode::settled>
>,
boost::multi_index::composite_key_compare<
std::less<double>,   //minDist order by normal order
Comp // size of settled
>
>
>
>;


#define EPS 0.0
void multisource_uniform_cost_search_seq(vector<vector<double>> &dists, set<Vertex> &sources, set<Vertex> &targets, Graph_t &g, set<Vertex> landMarks, DistanceCache &distanceCache){
    // minimum cost upto
    // goal state from starting
    // state

    // insert the starting index
    // map to store visited node
    set<Vertex> visited;
    set<Vertex> settledNodes;
    // create a priority heap
    Heap heap;
    auto& indexByV = heap.get<VisNodeByV>(); // here's where index tags (=names) come in handy
    auto& indexByD = heap.get<VisNodeByD>();
    //    set<Vertex> dests(targets);
    int counter=0;
    int numSettled=0;
    int destsCount=0;
    bool finish=false;
    set<Vertex> dests(targets),ddests(targets);
    for(Vertex v:sources){
        VisNode *visNode=new VisNode(v, sources, distanceCache);
        numSettled += visNode->settled.size();
        visNode->update_distance(v,0.0);
        indexByD.insert(visNode);
    }
    int iii=0;
    for(Vertex t:dests){
        if (ddests.count(t)>0){
            int indexj=std::distance(dests.begin(),dests.find(t));
            for (auto it=indexByV.begin(); it!=indexByV.end();it++){
                (*it)->update_potential(t, g, landMarks, distanceCache);
                indexByV.modify(it, VisNode::update_minDist((*it)->get_minDistance()));
            }
            // count
            bool targetFinished=false;
            // while the queue is not empty
            while (indexByV.size()!=0) {
                counter++;
                set<Vertex> settled;
                // get the top element of the
                // priority heap
                auto iter = indexByD.begin();
                VisNode *p = *iter;
                double nextDist;
                if (indexByD.size()>1){
                    nextDist = (*(++iter))->get_minPotentialDistance();
                } else{
                    nextDist = p->get_minPotentialDistance();
                }
                indexByV.erase(p->v);
                settled = p->settle_distances(nextDist, distanceCache);
                numSettled +=settled.size();
                // pop the element
                // check if the element is part of
                // the goal list
                // if all goals are reached
                // check for the non visited nodes
                // which are adjacent to present node
                if (visited.count(p->v) == 0) {
                    //p->v have not been visited
                    VisNode *visNode;
                    pair<AdjacencyIterator, AdjacencyIterator> nA = adjacent_vertices(p->v, g);
                    for (; nA.first != nA.second; nA.first++) { //loop over all neighbors if p->v
                        Vertex neighbor=*(nA.first);
                        if ((neighbor != p->v) && (visited.count(neighbor) == 0)) { //it is not in visited and check for loops
                            auto e = edge(p->v, *(nA.first), g);
                            if (!e.second){
                                e=edge(*(nA.first),p->v, g);
                            }
                            double l = g[e.first].distance;
                            auto it = indexByV.find(neighbor); //check if  the neighbor is on the heap
                            if (it == indexByV.end()) { //it is not on the heap we have to add it
                                visNode = new VisNode(neighbor,sources,distanceCache);
                                numSettled += visNode->settled.size();
                                visNode->update_potential(t,g,landMarks,distanceCache);
                            } else {
                                visNode=*it;
                                indexByV.erase(it);
                            }
                            if (visNode->indexNodeByV.size()>0){
                                for (auto s:p->settled){ //we loop on the settled of p->v
                                    Vertex currentSource = s.first;
                                    double currentDist = s.second.distance;
                                    double d = currentDist +l; //calculate the distance up to neighbor
                                    if (dests.count(*(nA.first)) > 0) {
                                        d = d - EPS; //heuristic
                                    }
                                    visNode->update_distance(currentSource,d);
                                }
                                auto itt=p->indexNodeByD.begin();
                                while(itt != p->indexNodeByD.end()){
                                    Vertex currentSource = (*itt)->v;
                                    double currentDist = (*itt)->distance;
                                    if (currentDist< nextDist) {
                                        p->settled[currentSource] = *(*itt);
                                        distanceCache.insert(currentSource,p->v, currentDist);
                                        itt = p->indexNodeByD.erase(itt);
                                        delete *itt;
                                    } else {
                                        if (currentDist !=
                                        std::numeric_limits<double>::infinity()) {//this source have already be seen by p->v
                                            double d = currentDist+l; //calculate the distance up to neighbor
                                            if (dests.count(*(nA.first)) > 0) {
                                                d = d - EPS; //heuristic
                                            }
                                            visNode->update_distance(currentSource, d);
                                        } else {
                                            break; // while(itt != p->indexNodeByD.end())
                                        }
                                        itt++;
                                    }// mark as visited
                                }
                                indexByD.insert(visNode);
                            } else {
                                auto J=dests.find(visNode->v);
                                if (J!=dests.end()) { // if the added node is a destination
                                    int indexj=std::distance(dests.begin(),J);
                                    if (visNode->is_fullySettled()) {
                                        for (auto e:visNode->settled) {
                                            int indexi=std::distance(sources.begin(),sources.find(e.first));
                                            dists[indexi][indexj] =e.second.distance;
                                        }
                                        destsCount++;
                                        ddests.erase(visNode->v);
                                        indexByD.insert(visNode);
                                        if (visNode->v == t) {
                                            targetFinished=true; //while (indexByV.size()!=0)
                                        }
                                    } else {
                                        indexByD.insert(visNode);
                                    }
                                } else{
                                    indexByD.insert(visNode);
                                }
                            }
                        }
                    }
                }
                auto J=dests.find(p->v);
                if (J!=dests.end()) {
                    // if a new dest is reached
                    int indexj=std::distance(dests.begin(),J);
                    if (p->is_fullySettled()) {
                        for (auto e:p->settled) {
                            int indexi=std::distance(sources.begin(),sources.find(e.first));
                            dists[indexi][indexj] =e.second.distance;
                        }
                        destsCount++;
                        visited.insert(p->v);
                        indexByV.erase(p->v);
                        ddests.erase(p->v);
                        Vertex current=p->v;
                        delete p;
                        if (current==t) {
                            targetFinished=true; //while (indexByV.size()!=0)
                        }
                    } else {
                        indexByD.insert(p);
                    }
                } else {
                    if (p->is_fullySettled()) {
                        visited.insert(p->v);
                        indexByV.erase(p->v);
                        Vertex current=p->v;
                        delete p;
                        if (current==t) {
                            targetFinished=true;
                        }
                    } else {
                        indexByD.insert(p);
                    }
                }
                if (targetFinished)
                    break;
            }
        }
        if (ddests.size()==0) {
            for (auto ite=indexByV.begin(); ite!=indexByV.end();ite++){
                delete *ite;
            }
            indexByV.clear();
            finish= true;
            break;
        }
        iii++;
    }
    if (ddests.size()>0)
        int KKKKK=0;
}

/*void multisource_uniform_cost_search_mincost(vector<vector<double>> &dists, set<Vertex> &sources, set<Vertex> &dests, Graph_t &g){
    // minimum cost upto
    // goal state from starting
    // state

    // insert the starting index
    // map to store visited node
    set<Vertex> visited;
    // create a priority heap
    Heap heap;
    auto& indexByV = heap.get<VisNodeByV>(); // here's where index tags (=names) come in handy
    auto& indexByD = heap.get<VisNodeByD>();
    for(Vertex v:sources){
        VisNode *visNode=new VisNode(v,t,sources, g,landMarks);
        indexByV.insert(visNode);
    }

    // count
    int count = 0;
    int numSettled=0;
    int counter=0;
    // while the queue is not empty
    while (indexByV.size() > 0) {
        // get the top element of the
        // priority heap
        counter++;
        list<Vertex> settled;
        auto iter = indexByD.begin();
        VisNode *p = *iter;
        cout<<counter<<","<<p->v<<","<<p->minDist<<","<<indexByV.size()<<","<<numSettled<<endl;
        double nextDist = (*(iter++))->minDist;
        auto it = p->indexNodeByD.begin();
        while (it != p->indexNodeByD.end()) {
            Vertex currentSource = (*it)->v;
            double currentDistance = (*it)->distance;
            if (currentDistance == std::numeric_limits<float>::infinity()){
                if (g[currentSource].distances.count(p->v)>0){
                    settled.push_front(currentSource);
                    p->settled[currentSource].distance = currentDistance;
                    it=p->indexNodeByD.erase(it);
                } else {
                    break;
                }
            } else {
                if (currentDistance <= nextDist) {
                    settled.push_front(currentSource);
                    p->settled[currentSource].distance = currentDistance;
                    g[p->v].distances[(*it)->v]= currentDistance;
                    g[(*it)->v].distances[p->v]= currentDistance;
                    it=p->indexNodeByD.erase(it);
                } else {
                    break;
                }
            }
        }
        if (p->indexNodeByD.size()==0){
            indexByV.erase(p->v);
        }
        // pop the element
        // check if the element is part of
        // the goal list
        auto J=dests.find(p->v);
        if (J!=dests.end()) {
            // if a new dest is reached
            for (Vertex v:settled) {
                numSettled++;
                auto I=sources.find(v);
                int indexi=std::distance(sources.begin(),I);
                int indexj=std::distance(dests.begin(),J);

                dists[indexi][indexj] = p->settled[v].distance;
//                cout << v << "," << p->v << "," << dists[indexi][indexj]<< ","<< numSettled<<endl;
            }
            if (p->indexNodeByV.size() == 0) {
                count++;
            } else {
                indexByV.modify(indexByV.find(p->v), VisNode::minDistChange((*p->indexNodeByD.begin())->distance));
            }
            if (count == dests.size()) {
                indexByV.clear();
                return;
            }
        }
        // if all goals are reached
        // check for the non visited nodes
        // which are adjacent to present node
        if (visited.count(p->v) == 0) {
            for (auto &vp:p->settled) {
                if (!vp.second.visited) {
                    Vertex currentSource = vp.first;
                    double currentDist = vp.second.distance;
                    if (currentDist != std::numeric_limits<float>::infinity()) { //the vertex is reached from currentSource
                        pair<AdjacencyIterator, AdjacencyIterator> nA = adjacent_vertices(p->v, g);
                        for (; nA.first != nA.second; nA.first++) {//loop over all neighbors if p->v
                            Vertex neighbor=*(nA.first);
                            if (neighbor != p->v) {//Check for loops
                                auto e = edge(p->v, neighbor, g);
                                double d = currentDist + g[e.first].distance; //calculate the distance up to neighbor
                                if (dests.count(neighbor) > 0) {
                                    d = d - EPS; //heuristic
                                }
                                auto it1 = indexByV.find(neighbor); //check if  the neighbor is on the heap
                                if (it1 == indexByV.end()){ //it is not on the heap we have to add it
                                    if (visited.count(neighbor)==0){
                                        VisNode *visNode = new VisNode(neighbor, sources,g);
                                        auto itt1 = visNode->indexNodeByV.find(currentSource);
                                        if (itt1!=visNode->indexNodeByV.end()){
                                            visNode->indexNodeByV.modify(itt1, IntNode::distChange(d));
                                            visNode->minDist = (*visNode->indexNodeByD.begin())->distance;
                                        }
                                        indexByD.insert(visNode);
                                    } else {
                                        int KK=0;
                                    }
                                } else {
                                    auto itt1 = (*it1)->indexNodeByV.find(currentSource);
                                    if (itt1 != (*it1)->indexNodeByV.end()) {
                                        if ((*itt1)->distance > d) {
                                            (*it1)->indexNodeByV.modify(itt1, IntNode::distChange(d));
                                            indexByV.modify(it1, VisNode::minDistChange(
                                                    (*(*it1)->indexNodeByD.begin())->distance));
                                        }
                                    } //else the vertex has already be settled for source in (*itt)->v
                                }
                            }
                        }
                    }
                    vp.second.visited=true;
                }
            }
            for (auto itt = p->indexNodeByD.begin(); itt != p->indexNodeByD.end(); itt++) {//loop over all sources in p->v
                if (!(*itt)->visited) {
                    Vertex currentSource = (*itt)->v;
                    double currentDist = (*itt)->distance;
                    if (currentDist !=
                        std::numeric_limits<float>::infinity()) {//this source have already be seen by p->v
                        pair<AdjacencyIterator, AdjacencyIterator> nA = adjacent_vertices(p->v, g);
                        for (; nA.first != nA.second; nA.first++) { //loop over all neighbors if p->v
                            if (*(nA.first) != p->v) {//Check for loops
                                auto e = edge(p->v, *(nA.first), g);
                                double d = currentDist + g[e.first].distance; //calculate the distance up to neighbor
                                if (dests.count(*(nA.first)) > 0) {
                                    d = d - EPS; //heuristic
                                }
                                auto it1 = indexByV.find(*(nA.first)); //check if  the neighbor is on the heap
                                if (it1 == indexByV.end()) { //it is not on the heap we have to add it
                                    if (visited.count(*(nA.first))==0) {
                                        VisNode *visNode = new VisNode(*(nA.first), sources,g);
                                        auto itt1 = visNode->indexNodeByV.find(currentSource);
                                        visNode->indexNodeByV.modify(itt1, IntNode::distChange(d));
                                        visNode->minDist = (*visNode->indexNodeByD.begin())->distance;
                                        indexByD.insert(visNode);
                                    }
                                } else {
                                    auto itt1 = (*it1)->indexNodeByV.find(currentSource);
                                    if (itt1 != (*it1)->indexNodeByV.end()) {
                                        if ((*itt1)->distance > d) {
                                            (*it1)->indexNodeByV.modify(itt1, IntNode::distChange(d));
                                            indexByV.modify(it1, VisNode::minDistChange(
                                                    (*(*it1)->indexNodeByD.begin())->distance));
                                        }
                                    } //else the vertex has already be settled for source in (*itt)->v
                                }
                            }
                        }
                        (*itt)->visited=true;
                    } else {
                        break;
                    }
                }
            }
            // mark as visited
        }
        if (p->indexNodeByV.size() == 0) {
            visited.insert(p->v);
            //           p->settled.clear();
            delete (p);
        } else {
            indexByV.modify(indexByV.find(p->v), VisNode::minDistChange((*p->indexNodeByD.begin())->distance));
        }
    }
}*/




/*set<Vertex> setLandmarks(int numLand, Graph_t &g){
    int numVertices=num_vertices(g);
    IndexMap index = get(vertex_index,g);
    vector<Vertex> parent(numVertices);
    auto t1 = high_resolution_clock::now();
    int count=0;
    Vertex landMark =1;
    set<Vertex> landMarks;
    while (count < numLand){
        try {
            dijkstra_shortest_paths(g, landMark,
                                    predecessor_map(make_iterator_property_map(parent.begin(),get(boost::vertex_index,g)))
                                            .distance_map(make_iterator_property_map(distances[count].begin(),get(boost::vertex_index,g)))
                                            .weight_map(get(&Edge_info::distance, g))
            );
        }
        catch (int exception) {
        }
        std::priority_queue<std::pair<double, int>> q;
        for(int i=0;i<distances[count].size();i++){
            g[landMark].distances[i]=distances[count][i];
            q.push(std::pair<double, int>(distances[count][i], i));
        }
        landMarks.insert(landMark);
        while(true){
            int ki = q.top().second;
            double kdist=q.top().first;
            if (landMarks.count(ki)==0) {
                landMark = ki;
                break;
            }
            q.pop();
        }
        count++;
    }
    return landMarks;
}*/

void calcul_chemins(Vertex s, vector<std::vector<double>> &MatDist, set<Vertex> &sources, set<Vertex> &dests, Graph_t &g, DistanceCache &distanceCache){
    vector<double> distance(num_vertices(g));
    set<Vertex> landMarks;
    int landMarkSize=std::min((int)sources.size(),8);
    landMarks.clear();
    int count=0;
    pair<AdjacencyIterator, AdjacencyIterator> nA = adjacent_vertices(s, g);
    for(auto iterA=nA.first;iterA != nA.second;++iterA) {
        if (count<landMarkSize){
            landMarks.insert(*iterA);
            count++;
        }
    }
    auto t1 = high_resolution_clock::now();
    multiSourceCone(s, g, sources, dests);
    for(int i=0;i<sources.size();i++){
        MatDist.push_back(vector<double>(dests.size(), std::numeric_limits<float>::infinity()));
    }
    multisource_uniform_cost_search_seq(MatDist,sources, dests,g, landMarks, distanceCache);
    auto t2 = high_resolution_clock::now();
    duration<double, std::micro> ms_double = t2 - t1;
    int j=0;
}


/*
 * Return the distance matrix between the edge' source and target neighbors
 */
void calcul_chemin(vector<std::vector<double>> &MatDist, Vertex s, Vertex d, Graph_t &g, DistanceCache &distanceCache) {
    vector<double> distance(num_vertices(g));
    pair<AdjacencyIterator, AdjacencyIterator> nA = adjacent_vertices(s, g);
    pair<AdjacencyIterator, AdjacencyIterator> nB = adjacent_vertices(d, g);
    set<Vertex> sources, dests, landMarks;
    int landMarkSize=std::min((int)sources.size(),8);
    landMarks.clear();
    int count=0;
    for(auto iterA=nA.first;iterA != nA.second;++iterA) {
        if (count<landMarkSize){
            landMarks.insert(*iterA);
            count++;
        }

        sources.insert(*iterA);
    }
    for(;nB.first!=nB.second;++nB.first) {
        dests.insert(*nB.first);
    }
    auto t1 = high_resolution_clock::now();
    /*
            try {


                dijkstra_shortest_paths(g, *(nA.first),
                                        predecessor_map(make_iterator_property_map(parent.begin(),get(boost::vertex_index,g)))
                                                .distance_map(make_iterator_property_map(distance.begin(),get(boost::vertex_index,g)))
                                                .weight_map(get(&Edge_info::distance, g))
                                                .visitor(vis)
                );

                //
                //distRed = uniform_cost_search(goal,start,  g1,cost);
            }
            catch (int exception) {
            }*/

    multisource_uniform_cost_search_seq(MatDist,sources, dests,g, landMarks, distanceCache);
    auto t2 = high_resolution_clock::now();
    duration<double, std::micro> ms_double = t2 - t1;
    int j=0;
}
//    cout<<"FIN CALL"<<endl;
/*
 * The main programme
 */
/*
void maj_distance(Graph_t g, Edge e, int delta_t) {
    Vertex s= source(e,g);
    Vertex d= target(e,g);
    vector<std::vector<double>> MatDist = calcul_chemin(s,d , g);
    int sA = out_degree(s,g);
    int sB = out_degree(d,g);
    double uA = (double) 1/sA;
    double uB = (double) 1/sB;
    vector<double> distributionA(sA, uA);
    vector<double> distributionB(sB, uB);
    double wd = compute_EMD(distributionA, distributionB, MatDist);
    cout<<"wd: "<<compute_EMD(distributionA, distributionB, MatDist)<<endl;
    auto ed = add_edge(source(e, g), target(e, g), g).first;
    g[ed].distance = -2*(1-wd)*delta_t;
}
*/

struct vertexpaircomp {
    // Comparator function
    bool operator()(const pair<Vertex, int>& l, const pair<Vertex, int>& r) const
    {
        if (l.second != r.second) {
            return l.second < r.second;
        }
        return l.first < r.first;
    }
};

int main() {
    Graph_t gin;
    Graph_t g;
    readGraphMLFile(gin, "/Users/ksalamatian/CLionProjects/Curvature/graphdumps1554598943.1554599003.graphml");
    k_core(gin,g, 2);
    Graph_t::vertex_iterator v, vend;
    set<pair<Vertex, int>, vertexpaircomp> degreeSorted;
    for (tie(v, vend) = vertices(g); v != vend; degreeSorted.insert(make_pair(*v,degree(*v++,g))));
    Graph_t::edge_iterator ei, ei_end;
    tie(ei, ei_end) = edges(g);
    vector<Edge> edges(ei,ei_end);
    vector<double> distances(edges.size());
    //    DistanceCache distanceCache(100000000,8);
    DistanceCache distanceCache(20000000,8);
    std::atomic<int> numProcessedVertex(0), numProcessedEdge(0);
    int numEdge=edges.size();
    int num_core=std::thread::hardware_concurrency();
    vector<Vertex> sortedVertices(degreeSorted.size());
    //The below part is for load balancing in the parallel loop.
    set<pair<Vertex, int>, vertexpaircomp>::iterator setIter=degreeSorted.begin();
    int scale=sortedVertices.size()/num_core;
    int offset=0;
    int k=0;
    for (auto p:degreeSorted){
        offset=(k%num_core)*scale+k/num_core;
        sortedVertices[offset]=p.first;
        k++;
    }
    parallel_for(blocked_range<int>(0,sortedVertices.size(),1000),
                 [&](blocked_range<int> r)
                 {
        try {
            double averageTime =0.0;
            double totalTime=0;
            for (int i=r.begin(); i<r.end(); ++i) {
                auto t1 = high_resolution_clock::now();
                Vertex s=sortedVertices[i];
                vector<vector<double>> MatDist;
                //                             calcul_chemin(MatDist,s, d, gcopy, distanceCache);
                set<Vertex> sources, dests;
                calcul_chemins(s, MatDist, sources, dests, g, distanceCache);
                if (dests.size()>0){// dests.size()==0 when all neighbor edege have already be studied.
                    pair<AdjacencyIterator, AdjacencyIterator> nA = adjacent_vertices(s, g);
                    for (; nA.first != nA.second; nA.first++) { //loop over all neighbors if p->v
                        Vertex neighbor=*(nA.first);
                        vector<vector<double>> vertDist(MatDist.size(),vector<double>(out_degree(neighbor, g),std::numeric_limits<double>::infinity()));
                        pair<AdjacencyIterator, AdjacencyIterator> nB = adjacent_vertices(neighbor, g);
                        int cntD=0;
                        set<Vertex> localDests;
                        for (; nB.first != nB.second; localDests.insert(*nB.first++)){
                            int indexj=std::distance(dests.begin(),dests.find(*(nB.first)));
                            for(int j=0;j<MatDist.size();j++){
                                vertDist[j][cntD]=MatDist[j][indexj];
                            }
                            cntD++;
                        }
                        int sA=vertDist.size(), sB=vertDist[0].size();
                        double uA = (double) 1 / sA ;
                        double uB = (double) 1 / sB ;
                        vector<double> distributionA(sA, uA);
                        vector<double> distributionB(sB, uB);
                        double wd = compute_EMD(distributionA, distributionB, vertDist);
                        if (isnan(wd)){
                            int KKK=0;
                        }
                        auto e=edge(s, neighbor, g);
                        if (!e.second){
                            e=edge(neighbor,s, g);
                        }
                        g[e.first].curvature=1-wd/g[e.first].distance;
                    }
                    auto t2 = high_resolution_clock::now();
                    duration<double, std::micro> ms_double = t2 - t1;
                    totalTime +=ms_double.count();
                    averageTime =totalTime/(i-r.begin()+1);
                    numProcessedVertex++;
                    numProcessedEdge +=MatDist.size();
                    cout<<ms_double.count()<<","<<averageTime<<","<<numProcessedVertex<<","<<numProcessedEdge<<","<< distanceCache.hit*1.0/(distanceCache.hit+distanceCache.miss)<<","<<matchedVertices*1.0/checkedVertices<<endl;
                }
                setIter++;
            }
        }catch (const tbb::captured_exception &exc) {
            cout << "Type: " << typeid(exc).name() << "\n";
        }
                 });
    boost::dynamic_properties dp;
    dp.property("asNumber", get(&Vertex_info::asnumber, g));
    //dp.property("pathnum", get(&Vertex_info::pathnum, designG));
    dp.property("Country", get(&Vertex_info::country, g));
    dp.property("Name", get(&Vertex_info::name, g));
    dp.property("asTime", get(&Vertex_info::astime, g));
    dp.property("prefixNum", get(&Vertex_info::prefixnum, g));
    dp.property("prefixAll", get(&Vertex_info::prefixall, g));
    // dp.property("addAll", get(&Vertex_info::addall, designG));
    // dp.property("addNum", get(&Vertex_info::addnum, designG));
    dp.property("count", get(&Edge_info::pathcount, g));
    dp.property("edgeTime", get(&Edge_info::edgetime, g));
    dp.property("weight", get(&Edge_info::weight, g));
    dp.property("distance", get(&Edge_info::distance, g));
    dp.property("curvature", get(&Edge_info::curvature, g));
    ofstream outFile;
    outFile.open("/Users/ksalamatian/CLionProjects/Curvature/processed", ofstream::out);

    write_graphml(outFile, g, dp, true);
    return 0;
}
